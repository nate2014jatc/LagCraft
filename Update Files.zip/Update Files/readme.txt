We're downgrading to an old version of the blood magic api to fix a text wrapping issue in the book so:


	What You Need To Do

Delete Guide-API-1.7.10-1.0.1-29
Then copy in the new files as usual



	What This Update Is Doing

Minor rebalance/buff of powersuits
Fixing Blood Magic book text wrapping problem