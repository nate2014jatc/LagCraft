We're downgrading to an old version of the blood magic api to fix a text wrapping issue in the book so:


	What You Need To Do

Delete the "modpack" folder in the main directory
Delete the mod Guide-API-1.7.10-1.0.1-29 in the "mods" directory
Then copy in the new files as usual



	What This Update Is Doing

Minor rebalance/buff of powersuits
Fixing Blood Magic book text wrapping problem
hopefully making osmium actually spawn
also probably fixing green heart crafting recipe